package ejercicio;

public interface IAparcamiento {
	
	public double calcularPrecio(double precioMin);

}
