package ejercicio;

public class CashException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CashException(String s) {
		super(s);
	}
}
