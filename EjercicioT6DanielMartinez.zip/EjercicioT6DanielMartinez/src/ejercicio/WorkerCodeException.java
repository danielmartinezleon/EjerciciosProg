package ejercicio;

public class WorkerCodeException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public WorkerCodeException(String s) {
		super(s);
	}

}
