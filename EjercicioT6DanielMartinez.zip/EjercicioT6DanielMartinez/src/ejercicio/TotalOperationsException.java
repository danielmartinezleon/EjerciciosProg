package ejercicio;

public class TotalOperationsException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TotalOperationsException(String s) {
		super(s);
	}
}
