package ejercicio02;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	double largo=50;
	double ancho=21;
	double profundidad=2.5;
	
	double radio=12;
	double piscina1=0;
	double piscina2=0;
	double profundidad2=1.80;	
	double precioLitros=1.80;
	double precioPiscina1=0;
	double precioPiscina2=0;
	
	piscina1=largo*ancho*profundidad;
	piscina2=Math.PI*Math.pow(radio,2)*profundidad2;
	precioPiscina1=precioLitros*piscina1;
	precioPiscina2=precioLitros*piscina2;
	
	System.out.println("Buenas tardes/dias/noches, hoy vamos a realizar unos calculos con dos piscinas");
	System.out.println("********************************************************************************************************************************************");
	System.out.println("");
	System.out.println("Primero vamos medir la primera piscina");
	System.out.println("");
	System.out.printf("%.2f m3 es lo que mide la primera piscina\n", piscina1);
	System.out.println("********************************************************************************************************************************************");
	System.out.println("");
	System.out.println("A continuacion vamos a medir la segunda piscina");
	System.out.println("");
	System.out.printf("%.2f m3 es lo que mide la segunda piscina\n", piscina2);
	System.out.println("********************************************************************************************************************************************");
	System.out.println("");
	System.out.println("Ahora vamos a calcular lo que costaria llenar ambas piscinas");
	System.out.println("");
	System.out.printf("%.2f euros es lo que nos costaria rellenar la priemera piscina\n", precioPiscina1);
	System.out.printf("%.2f euros es lo que nos costaria rellenar la segunda piscina\n",precioPiscina2);
	System.out.println("********************************************************************************************************************************************");
	System.out.println("");
	System.out.println("Pues esta seria la practica, donde podemos ver lo que mide cada piscina en m3, y lo que costaria llenar ambas");
		
		
		
		
		
	}

}
