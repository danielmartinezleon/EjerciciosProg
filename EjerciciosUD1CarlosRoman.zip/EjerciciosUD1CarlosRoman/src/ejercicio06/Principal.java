package ejercicio06;

public class Principal {

	public static void main(String[] args) {
		
		double ps5=450;
		double ps5Descuento=0.0;
		double descuento=20;
		double porciento=100;
		double ps5PrecioFinal=0.0;
		
		ps5Descuento=ps5*20/porciento;
		ps5PrecioFinal=ps5-ps5Descuento;
		System.out.println("Vamos a calcular el precio de una ps5 de 450 euros  con un descuento del 20%");
		System.out.println("//////////////////////////////////////////////////////////////");
		System.out.printf("%.2fes lo que nos descontaria a  nuestra ps5 con un descuento del 20 por ciento\n", ps5Descuento);
		System.out.println("//////////////////////////////////////////////////////////////");
		System.out.println("Y ahora para saber lo que nos costaria hacemos una resta de los 90 euros al precio inicial de la ps5");
		System.out.printf("%.2f es lo que pagariamos finalmente por nuestra ps5",ps5PrecioFinal);
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
