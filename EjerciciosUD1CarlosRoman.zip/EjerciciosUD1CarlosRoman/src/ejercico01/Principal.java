package ejercico01;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int calcetin=3;
		int camiseta=5;
		int sudadera=9;
		int resultado=17;
		
		System.out.println("Buenos dias, vamos a hacer una suma de variables");
		System.out.println(calcetin+camiseta+sudadera+" es el resultado del calcetin mas la camiseta mas la sudadera");
		System.out.println(resultado-1+" es lo que nos da si al resultado le restamos uno");
		
											
	}	

}
