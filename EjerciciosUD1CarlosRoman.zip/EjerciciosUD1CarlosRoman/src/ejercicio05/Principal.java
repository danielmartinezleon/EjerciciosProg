 package ejercicio05;

public class Principal {


	public static void main(String[] args) {
		
		double euro=50;
		double librasesterlinas=1.50;
		double total= euro*librasesterlinas;
		
		
		System.out.println("Buenos dias, vamos a calcular el valor de una libra en euros");
		System.out.printf("Un euro a libra esterlina cuesta %.2f ",total);
		
		
		
		
		
		

	}

}
